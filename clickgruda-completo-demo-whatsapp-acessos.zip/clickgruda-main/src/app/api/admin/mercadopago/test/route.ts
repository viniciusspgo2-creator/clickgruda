import { getSessionUser, jsonError } from '@/lib/auth'
import { getSettings } from '@/lib/settings'
export async function POST() {
  if ((await getSessionUser())?.role !== 'ADMIN') return jsonError('Acesso restrito ao master', 401)
  const s = await getSettings(['mercadopago_access_token'])
  if (!s.mercadopago_access_token?.trim()) return jsonError('Salve o Access Token antes de testar.', 400)
  try {
    const res = await fetch('https://api.mercadopago.com/users/me', { headers: { Authorization: `Bearer ${s.mercadopago_access_token}` }, cache: 'no-store', signal: AbortSignal.timeout(12000) })
    if (!res.ok) return jsonError('O Mercado Pago recusou a credencial. Confira o Access Token e o ambiente da sua aplicação.', 400)
    const data = await res.json()
    return Response.json({ connected: true, account: data.nickname || data.first_name || 'Conta Mercado Pago', message: 'Credencial aceita pelo Mercado Pago. Nenhuma cobrança foi criada.' })
  } catch { return jsonError('Não foi possível consultar o Mercado Pago agora. Tente novamente.', 502) }
}
